# GIFI to FS caption rules

Grouping (by GIFI code):
- Current assets 1000-1599 (1000-1059 merged into "Cash and cash equivalents")
- Non-current assets 1600-2589
- Current liabilities 2600-3139
- Non-current liabilities 3140-3450 (3260 due to shareholder long-term)
- Equity 3500-3599 plus retained earnings 3600
- Revenue 8000-8299, cost of sales 8300-8518, expenses 8520-9367
- Totals and subtotal codes are ignored and recalculated.

Caption overrides live in `CAP` in scripts/build_model.py. Add a code there when the GIFI label reads badly. Keep captions short, sentence case.

Related-party lines (label contains "related" or "affiliat") need a name from intake: `--related CODE="Name"`.
