// Management Responsibility Acknowledgement (MAL). Management's letter to the firm, signed by the corporation's signing officer.
// Wording follows the firm's MAL (Management Acknowledgement Letter, Dec 2023). Input: model.json.
const fs=require('fs'),path=require('path');
const {Document,Packer,Paragraph,TextRun,AlignmentType,Header,ImageRun,BorderStyle}=require('docx');
const m=JSON.parse(fs.readFileSync(process.argv[2]));const out=process.argv[3];
const F='Arial',SZ=20;const t=(s,o={})=>new TextRun({text:s,font:F,size:o.size||SZ,bold:o.bold,color:o.color});
const p=(runs,o={})=>new Paragraph({spacing:{after:o.after??160,line:276},alignment:o.align||AlignmentType.LEFT,border:o.line?{top:{style:BorderStyle.SINGLE,size:6,color:'000000',space:4}}:undefined,children:Array.isArray(runs)?runs:[t(runs,o)]});
const FIRM='Concept Accounting & Advisory Professional Corporation';
const off=m.officer?(m.officer.first+' '+m.officer.last):'[Signing officer]';
const pos=m.officer_pos||(m.officer&&m.officer.position)||'[Position]';
const per=m.period.charAt(0).toLowerCase()+m.period.slice(1);
const A=m.addr,tc=s=>s.toLowerCase().replace(/\b\w/g,c=>c.toUpperCase()).replace(/\b(Sw|Se|Nw|Ne)\b/g,x=>x.toUpperCase());
// Management's letter: plain paper, sender block is the corporation. Never on firm letterhead.
const body=[p([t(m.name,{bold:true,size:24})],{after:0}),p(tc(A.street)+(A.street2?', '+tc(A.street2):''),{after:0}),p(tc(A.city)+' '+A.prov+'  '+A.postal,{after:360}),
 p([t('Management Responsibility Acknowledgement',{bold:true,size:24})],{align:AlignmentType.CENTER,after:360}),
 p(m.report_date,{after:240}),
 p(FIRM,{after:0}),p('675 Riverbend Dr.',{after:0}),p('Kitchener, ON  N2K 3S3',{after:240}),
 p('To: '+FIRM,{after:240}),
 p('As management of '+m.name+', I am writing to acknowledge and confirm my responsibility for the final version of the financial statements and related disclosures compiled by your firm on behalf of '+m.name+' '+per+'.',{align:AlignmentType.JUSTIFIED}),
 p('In addition, I approve all adjusting entries and reclassifications made by '+FIRM+' to the company\'s financial information during the course of your compilation of the above financial statements.',{align:AlignmentType.JUSTIFIED,after:480}),
 p('Yours truly,',{after:960}),
 p(off,{line:true,after:0}),p(m.name,{after:0}),p(pos,{after:240}),
 p('Date: '+m.report_date)];
const doc=new Document({styles:{default:{document:{run:{font:F,size:SZ}}}},sections:[{properties:{page:{size:{width:12240,height:15840},margin:{top:1080,bottom:1080,left:1440,right:1440}}},
 headers:{default:new Header({children:[new Paragraph({children:[t('DRAFT FOR REVIEW',{bold:true,size:16,color:'C00000'})]})]})},children:body}]});
Packer.toBuffer(doc).then(b=>fs.writeFileSync(out,b));
