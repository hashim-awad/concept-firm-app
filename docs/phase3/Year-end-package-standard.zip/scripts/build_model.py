import json,sys,datetime as dt
from parse_t2 import parse,checks
CAP={'1000':'Cash and cash equivalents','1060':'Accounts receivable','1062':'Allowance for doubtful accounts','1480':'Prepaid expenses and deposits',
 '2620':'Accounts payable and accrued liabilities','2680':'Income taxes payable','3260':'Due to shareholder','2780':'Due to shareholder',
 '3500':'Share capital','8000':'Revenue','8523':'Meals and entertainment','8690':'Insurance','8715':'Interest and bank charges',
 '8810':'Office expenses','9060':'Salaries and wages','9225':'Telecommunications','9281':'Vehicle','8520':'Advertising','8860':'Professional fees',
 '8910':'Rent','9270':'Other expenses','8670':'Amortization'}
GROUP={'1000':range(1000,1060)}
TOTALS={'2599','3499','3620','3640','3849','3660','3680','3600','8089','8299','8519','9367','9368','9369','9970','9990','9999','9659','9898','9899','8518','8300'}
def fmt_date(s):
    try: d=dt.date.fromisoformat(s)
    except Exception: return s  # placeholder such as [Date of signing]
    return d.strftime('%B ')+str(d.day)+d.strftime(', %Y')
MISSING=[]
def build(pdf,hst=0,report_date=None,sh_terms=None,related=None):
    related=related or {}
    d=parse(pdf); ck=checks(d)
    bad=[c for c in ck if c[3]!='OK']
    if bad: raise SystemExit('STOP: tie-out failed: %s'%bad)
    b=d['s100']; i=d['s125']
    has_prior=any(v['pri'] for v in b.values())
    def val(v,k): return v.get(k) or 0
    def lines(lo,hi,src):
        out={}
        for c,v in src.items():
            n=int(c)
            if c in TOTALS or not (lo<=n<=hi): continue
            if not (v['cur'] or v['pri']): continue
            key='1000' if 1000<=n<1060 else c
            cap=CAP.get(key) or v['label'][:1].upper()+v['label'][1:].lower()
            if c in related: cap=cap+' ('+related[c]+')'
            if ('related' in v['label'].lower() or 'affiliat' in v['label'].lower()) and c not in related: MISSING.append('Related party name for GIFI '+c+' ('+v['label']+')')
            o=out.setdefault(key,{'cap':cap,'cur':0,'pri':0,'code':c})
            o['cur']+=val(v,'cur'); o['pri']+=val(v,'pri')
        return list(out.values())
    ca=lines(1000,1599,b); nca=lines(1600,2589,b)
    cl=lines(2600,3139,b); ncl=lines(3140,3450,b)
    for r in cl:
        if r['code']=='2680' and hst:
            r['cur']-=hst; cl.insert(cl.index(r)+1,{'cap':'GST/HST payable','cur':hst,'pri':0,'code':'HST'}); break
    eq=lines(3500,3599,b)+[{'cap':'Retained earnings (deficit)','cur':val(b.get('3600',{}),'cur'),'pri':val(b.get('3600',{}),'pri'),'code':'3600'}]
    rev=lines(8000,8299,i); cos=lines(8300,8518,i); exp=lines(8520,9367,i)
    ys=d.get('year_start'); ye=d['year_end']
    days=(dt.date.fromisoformat(ye)-dt.date.fromisoformat(ys)).days+1 if ys else 365
    period=('For the year ended '+fmt_date(ye)) if days>=358 else ('For the period from '+fmt_date(ys)+' to '+fmt_date(ye))
    y=ye[:4]; py=str(int(y)-1)
    sh_note=[r for r in ncl+cl if r['code'] in ('3260','2780')]
    m={'name':d['legal_name'],'period':period,'asat':'As at '+fmt_date(ye),'y':y,'py':py,'has_prior':has_prior,
       'bs':{'ca':ca,'nca':nca,'cl':cl,'ncl':ncl,'eq':eq},
       'is':{'rev':rev,'cos':cos,'exp':exp,'tax':{'cur':val(i.get('9990',{}),'cur'),'pri':val(i.get('9990',{}),'pri')},
             'ni':{'cur':val(i.get('9999',{}),'cur'),'pri':val(i.get('9999',{}),'pri')},
             're_open':{'cur':val(b.get('3660',{}),'cur'),'pri':val(b.get('3660',{}),'pri')},
             're_close':{'cur':val(b.get('3849',{}),'cur'),'pri':val(b.get('3849',{}),'pri')},'ppa':{'cur':val(b.get('3720',{}),'cur'),'pri':val(b.get('3720',{}),'pri')}},
       'notes':{'shareholder':sh_note,'has_ar':any(r['code'] in('1060',) for r in ca),'has_ap':any(r['code']=='2620' for r in cl),
                'has_ppe':bool(nca),'has_sd':any(r['code']=='2627' for r in cl),'has_tax':any(r['code']=='2680' for r in cl),'has_hst':bool(hst)},
       'balance':d.get('balance'),'instalments':d.get('instalments'),'bn15':d['bn9'][:5]+' '+d['bn9'][5:]+' RC 0001',
       'fed_tax':d.get('fed_tax'),'prov_tax':d.get('prov_tax'),'sbd':d.get('sbd'),'days':days,'year_end':ye,'year_start':ys,
       'checks':ck,'missing':MISSING,'sh_terms':sh_terms,'has_s3_dividends':d.get('has_s3_dividends'),'officer_pos':(d.get('officer') or {}).get('position'),
       'addr':d['address'],'officer':d.get('officer'),'is_year':days>=358,
       'report_date':fmt_date(report_date or d.get('cert_date')),'report_date_src':'intake' if report_date else 'T2 line 955 (certification date)'}
    # arithmetic self-check
    S=lambda rs,k: sum(r[k] for r in rs)
    assert S(ca+nca,'cur')==val(b['2599'],'cur'), 'assets'
    assert S(cl+ncl,'cur')+S(eq,'cur')==val(b['3640'],'cur'), 'L+E'
    assert S(rev,'cur')-S(cos,'cur')-S(exp,'cur')-m['is']['tax']['cur']==m['is']['ni']['cur'], 'NI'
    return m
