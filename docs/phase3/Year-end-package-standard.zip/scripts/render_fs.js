const fs=require('fs');
const {ImageRun,Document,Packer,Paragraph,TextRun,Table,TableRow,TableCell,WidthType,AlignmentType,BorderStyle,Footer,Header,PageNumber,PageBreak,LevelFormat,TabStopType}=require('docx');
const m=JSON.parse(fs.readFileSync(process.argv[2]));const out=process.argv[3];
const F='Arial', SZ=18, P=m.has_prior;
const W=P?[5460,600,1650,1650]:[6660,600,2100];
const n=v=>v==null||v===0?'-':(v<0?'('+Math.abs(v).toLocaleString('en-US')+')':v.toLocaleString('en-US'));
const none={style:BorderStyle.NONE,size:0,color:'FFFFFF'};
const NB={top:none,bottom:none,left:none,right:none};
const t=(s,o={})=>new TextRun({text:s,font:F,size:o.size||SZ,bold:o.bold,italics:o.it,color:o.color});
function cell(text,w,o={}){const b={...NB};
 if(o.top)b.top={style:BorderStyle.SINGLE,size:4,color:'000000'};
 if(o.dbl)b.bottom={style:BorderStyle.DOUBLE,size:6,color:'000000'};
 if(o.under)b.bottom={style:BorderStyle.SINGLE,size:4,color:'000000'};
 return new TableCell({width:{size:w,type:WidthType.DXA},borders:b,margins:{top:20,bottom:20,left:60,right:60},
  children:[new Paragraph({alignment:o.right?AlignmentType.RIGHT:(o.center?AlignmentType.CENTER:AlignmentType.LEFT),indent:o.indent?{left:240}:undefined,
   children:[t(text,{bold:o.bold})]})]});}
function row(cap,cur,pri,o={}){const c=[cell(cap,W[0],{bold:o.bold,indent:o.indent}),cell(o.note||'',W[1],{center:true})];
 const vo={right:true,bold:o.bold,top:o.top,dbl:o.dbl,under:o.under};
 c.push(cell(o.text?cur:n(cur),W[2],{...vo,bold:o.bold||true}));
 if(P)c.push(cell(o.text?pri:n(pri),W[3],vo));
 return new TableRow({children:c});}
const blank=()=>row('','','',{text:true});
const hdrRow=()=>row('',m.y,m.py,{text:true,bold:true,under:true});
const dollar=(cap)=>row(cap,'$','$',{text:true,bold:true});
const S=(rs,k)=>rs.reduce((a,r)=>a+r[k],0);
const tbl=rows=>new Table({width:{size:W.reduce((a,b)=>a+b),type:WidthType.DXA},columnWidths:W,rows});
function title(sub,line){return [new Paragraph({alignment:AlignmentType.RIGHT,children:[t(m.name,{bold:true,size:22})]}),
 new Paragraph({alignment:AlignmentType.RIGHT,children:[t(sub,{bold:true,size:20})]}),
 new Paragraph({alignment:AlignmentType.RIGHT,children:[t(line,{it:true})]}),
 new Paragraph({alignment:AlignmentType.RIGHT,spacing:{after:200},children:[t('(Unaudited - See Compilation Engagement Report)',{it:true,size:15})]})];}
function section(label,rs,totLabel,notes={}){const r=[row(label,'','',{text:true,bold:true})];
 rs.forEach((x,i)=>r.push(row(x.cap,x.cur,x.pri,{indent:true,note:notes[x.code]||''})));
 r.push(row(totLabel,S(rs,'cur'),S(rs,'pri'),{bold:true,top:true}));return r;}
// Balance sheet
const b=m.bs, notes={}; if(m.notes.shareholder.length) m.notes.shareholder.forEach(x=>notes[x.code]=((m.is.ppa&&m.is.ppa.cur)?'3':'2'));
let bs=[hdrRow(),dollar('ASSETS')];
bs=bs.concat(section('CURRENT ASSETS',b.ca,'TOTAL CURRENT ASSETS'));
if(b.nca.length){bs.push(blank());bs=bs.concat(section('NON-CURRENT ASSETS',b.nca,'TOTAL NON-CURRENT ASSETS',notes));}
const TA=S(b.ca.concat(b.nca),'cur'),TAp=S(b.ca.concat(b.nca),'pri');
bs.push(row('TOTAL ASSETS',TA,TAp,{bold:true,dbl:true}),blank(),row('LIABILITIES','','',{text:true,bold:true}));
bs=bs.concat(section('CURRENT LIABILITIES',b.cl,'TOTAL CURRENT LIABILITIES',notes));
if(b.ncl.length){bs.push(blank());bs=bs.concat(section('NON-CURRENT LIABILITIES',b.ncl,'TOTAL NON-CURRENT LIABILITIES',notes));}
const L=b.cl.concat(b.ncl);bs.push(row('TOTAL LIABILITIES',S(L,'cur'),S(L,'pri'),{bold:true,top:true}),blank());
bs=bs.concat(section("SHAREHOLDERS' EQUITY",b.eq,'TOTAL EQUITY'));
bs.push(blank(),row("TOTAL LIABILITIES AND SHAREHOLDERS' EQUITY",S(L,'cur')+S(b.eq,'cur'),S(L,'pri')+S(b.eq,'pri'),{bold:true,dbl:true}));
// Income statement
const I=m.is;let is=[hdrRow(),dollar('')];
is=is.concat(section('REVENUE',I.rev,'TOTAL REVENUE'));
let gp=S(I.rev,'cur'),gpp=S(I.rev,'pri');
if(I.cos.length){is.push(blank());is=is.concat(section('COST OF SALES',I.cos,'TOTAL COST OF SALES'));gp-=S(I.cos,'cur');gpp-=S(I.cos,'pri');is.push(row('GROSS PROFIT',gp,gpp,{bold:true}));}
is.push(blank());is=is.concat(section('EXPENSES',I.exp,'TOTAL EXPENSES'));
const ebt=gp-S(I.exp,'cur'),ebtp=gpp-S(I.exp,'pri');
is.push(blank(),row('INCOME BEFORE INCOME TAXES',ebt,ebtp,{bold:true}),row('Provision for income taxes',I.tax.cur,I.tax.pri,{indent:true}),
 row('NET INCOME (LOSS)',I.ni.cur,I.ni.pri,{bold:true,top:true}),blank(),
 row('RETAINED EARNINGS, BEGINNING OF PERIOD',I.re_open.cur,I.re_open.pri,{bold:true}));
const PPA=I.ppa||{cur:0,pri:0};
if(PPA.cur||PPA.pri){is.push(row('Prior period adjustment (Note 2)',PPA.cur,PPA.pri,{indent:true}),row('As restated',I.re_open.cur+PPA.cur,I.re_open.pri+PPA.pri,{top:true}));}
is.push(row('Net income (loss)',I.ni.cur,I.ni.pri,{indent:true}));
const div=I.re_open.cur+PPA.cur+I.ni.cur-I.re_close.cur, divp=I.re_open.pri+PPA.pri+I.ni.pri-I.re_close.pri;
if(div||divp) is.push(row('Dividends',-div,-divp,{indent:true}));
is.push(row('RETAINED EARNINGS, END OF PERIOD',I.re_close.cur,I.re_close.pri,{bold:true,top:true,dbl:true}));
// Notes
const para=(s,o={})=>new Paragraph({spacing:{after:120},children:[t(s,o)]});
const h=(s)=>new Paragraph({spacing:{before:200,after:80},children:[t(s,{bold:true})]});
const bullet=s=>new Paragraph({numbering:{reference:'b',level:0},children:[t(s)]});
const per=m.period.charAt(0).toLowerCase()+m.period.slice(1);
let nt=[h('1. Basis of accounting'),para(`The basis of accounting applied in the preparation of the balance sheet of ${m.name} as at ${m.asat.slice(6)}, and the statement of earnings and retained earnings ${per}, is the historical cost basis and reflects cash transactions with the addition of:`)];
const N=m.notes; if(N.has_ar)nt.push(bullet('Accounts receivable, less an allowance for doubtful accounts'));
if(N.has_ppe)nt.push(bullet('Property, plant and equipment, amortized over their useful lives'));
if(N.has_ap)nt.push(bullet('Accounts payable and accrued liabilities'));
if(N.has_sd)nt.push(bullet('Source deductions payable on salaries'));
if(N.has_tax)nt.push(bullet('Current income taxes payable as at the reporting date'));
if(N.has_hst)nt.push(bullet('GST/HST payable as at the reporting date'));
if(N.has_hst){nt.push(h('GST/HST'),para('Revenue and expenses are recorded net of GST/HST. Receivables and payables include GST/HST.'));}
let nn=2; const ppaAmt=(m.is.ppa&&m.is.ppa.cur)||0;
if(ppaAmt){nt.push(h((nn++)+'. Prior period adjustment'),para('Opening retained earnings has been '+(ppaAmt<0?'reduced':'increased')+' by $'+Math.abs(ppaAmt).toLocaleString('en-US')+' to correct an error in a prior period. Comparative figures have not been restated.'));}
if(N.shareholder.length){nt.push(h((nn++)+'. Due to shareholder'),para(m.sh_terms||('The amount due to the shareholder is non-interest bearing, unsecured, and has no set terms of repayment. It is classified as a '+(N.shareholder.some(x=>x.code==='3260')?'non-current':'current')+' liability.')));
 nt.push(tbl([hdrRow(),dollar('')].concat(N.shareholder.map(x=>row(x.cap,x.cur,x.pri,{indent:true}))).concat([row('',S(N.shareholder,'cur'),S(N.shareholder,'pri'),{bold:true,top:true,dbl:true})])));}

const A=m.addr,tc=s=>s.toLowerCase().replace(/\b\w/g,c=>c.toUpperCase()).replace(/\b(Sw|Se|Nw|Ne)\b/g,x=>x.toUpperCase());
const off=m.officer?(m.officer.first+' '+m.officer.last):'';
const pr=(runs,o={})=>new Paragraph({alignment:o.align||AlignmentType.JUSTIFIED,spacing:{after:o.after??160,line:276},children:runs});
const endLabel=m.is_year?'year':'period';
const report=[new Paragraph({children:[new ImageRun({type:'png',data:fs.readFileSync(require('path').join(__dirname,'..','assets','letterhead.png')),transformation:{width:624,height:93}})]}),
 new Paragraph({alignment:AlignmentType.CENTER,spacing:{before:360,after:360},children:[t('COMPILATION ENGAGEMENT REPORT',{bold:true,size:24})]}),
 pr([t(m.report_date)],{align:AlignmentType.LEFT,after:240}),
 pr([t(off)],{align:AlignmentType.LEFT,after:0}),pr([t(m.name)],{align:AlignmentType.LEFT,after:0}),
 pr([t(tc(A.street)+(A.street2?', '+tc(A.street2):''))],{align:AlignmentType.LEFT,after:0}),
 pr([t(tc(A.city)+' '+A.prov+'  '+A.postal)],{align:AlignmentType.LEFT,after:240}),
 pr([t('To Management of '+m.name)],{align:AlignmentType.LEFT,after:240}),
 pr([t('On the basis of information provided by management, we have compiled the balance sheet of '),t(m.name,{bold:true}),t(' as at '),t(m.asat.slice(6),{bold:true}),
   t(', the statement of earnings and retained earnings for the '+endLabel+' then ended, and Note 1, which describes the basis of accounting applied in the preparation of the compiled financial information ("financial information").')]),
 pr([t('Management is responsible for the accompanying financial information, including the accuracy and completeness of the underlying information used to compile it and the selection of the basis of accounting.')]),
 pr([t('We performed this engagement in accordance with Canadian Standard on Related Services (CSRS) 4200, Compilation Engagements, which requires us to comply with relevant ethical requirements. Our responsibility is to assist management in the preparation of the financial information.')]),
 pr([t('We did not perform an audit engagement or a review engagement, nor were we required to perform procedures to verify the accuracy or completeness of the information provided by management. Accordingly, we do not express an audit opinion or a review conclusion or provide any form of assurance on the financial information.')]),
 pr([t('Readers are cautioned that the financial information may not be appropriate for their purposes.')],{after:600}),
 pr([t('Concept Accounting & Advisory Professional Corporation',{bold:true,color:'1A3C7C'})],{align:AlignmentType.RIGHT,after:0}),
 pr([t('Chartered Professional Accountants',{it:true})],{align:AlignmentType.RIGHT,after:0}),
 pr([t('Kitchener, Ontario',{it:true})],{align:AlignmentType.RIGHT,after:0})];
const footer=new Footer({children:[new Paragraph({border:{top:{style:BorderStyle.SINGLE,size:6,color:'86BC26',space:4}},tabStops:[{type:TabStopType.RIGHT,position:9360}],
 children:[t('PRIVATE & CONFIDENTIAL | Intended solely for the named addressee.',{it:true,size:14,color:'666666'}),new TextRun({children:['\tPage ',PageNumber.CURRENT],font:F,size:14,color:'666666'})]}),
 new Paragraph({children:[t('Prepared by Concept Accounting & Advisory Professional Corporation | Registered with CPA Ontario',{size:14,color:'888888'})]})]});
const header=new Header({children:[new Paragraph({alignment:AlignmentType.LEFT,children:[t('DRAFT FOR REVIEW',{bold:true,size:16,color:'C00000'})]})]});
const pb=()=>new Paragraph({children:[new PageBreak()]});
const cover=[...Array(12)].map(()=>new Paragraph({children:[]})).concat([
 new Paragraph({alignment:AlignmentType.CENTER,children:[t(m.name,{bold:true,size:32})]}),new Paragraph({children:[]}),
 new Paragraph({alignment:AlignmentType.CENTER,children:[t('Compiled Financial Information',{bold:true,size:24})]}),
 new Paragraph({alignment:AlignmentType.CENTER,children:[t(m.period,{it:true,size:20})]})]);
const doc=new Document({numbering:{config:[{reference:'b',levels:[{level:0,format:LevelFormat.BULLET,text:'\u2022',alignment:AlignmentType.LEFT,style:{paragraph:{indent:{left:540,hanging:270}}}}]}]},
 styles:{default:{document:{run:{font:F,size:SZ}}}},
 sections:[{properties:{page:{size:{width:12240,height:15840},margin:{top:1080,bottom:1080,left:1440,right:1440}}},headers:{default:header},footers:{default:footer},
  children:[...cover,pb(),...report,pb(),...title('Balance Sheet',m.asat),tbl(bs),pb(),...title('Statement of Earnings and Retained Earnings',m.period),tbl(is),pb(),
   ...title('Notes to the Compiled Financial Information',m.period),...nt]}]});
Packer.toBuffer(doc).then(buf=>fs.writeFileSync(out,buf));
