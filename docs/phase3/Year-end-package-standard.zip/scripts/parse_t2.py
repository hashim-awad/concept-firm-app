import re, json, subprocess, sys
def txt(p): return subprocess.run(['pdftotext','-layout',p,'-'],capture_output=True,text=True).stdout
def num(s):
    if s is None: return None
    s=s.strip().replace(',','')
    neg=s.startswith('(') or s.startswith('-')
    s=s.strip('()-')
    return -int(s) if neg else int(s)
def parse(p):
    t=txt(p); pages=t.split('\f')
    m=re.search(r'Client: (.+?)\s+CRA Business # (\d{9})\s+Year-end: (\d{4}-\d{2}-\d{2})',t)
    d={'legal_name':m.group(1).strip(),'bn9':m.group(2),'year_end':m.group(3)}
    def gifi(title):
        pg=next((x for x in pages if title in x),None)
        rows={}
        if not pg: return rows
        prior_start=None
        for line in pg.splitlines():
            if 'Prior year' in line: prior_start=line.find('Prior year')
            r=re.match(r'^\s*(\S.*?\S)\s{2,}(\d{4})\b(.*)$',line)
            if not r: continue
            label,code,rest=r.groups()
            base=line.find(code,len(label))+4
            cur=pri=None
            for mm in re.finditer(r'[\d,()\-]*\d[\d,()\-]*',rest):
                end=base+mm.end()
                if prior_start and end>prior_start: pri=num(mm.group())
                else: cur=num(mm.group())
            rows[code]={'label':label,'cur':cur,'pri':pri}
        return rows
    d['s100']=gifi('BALANCE SHEET INFORMATION'); d['s125']=gifi('INCOME STATEMENT INFORMATION')
    # s125 page 2 (summary: 9990, 9999)
    for x in pages:
        if 'Net income / loss after taxes' in x:
            for c in ('9990','9999'):
                r=re.search(c+r'[ \t]+(\([\d,]+\)|[\d,]+|-)?[ \t]*[-=+]?[ \t]*(\([\d,]+\)|[\d,]+)?[ \t]*$',x,re.M)
                if r: d['s125'][c]={'label':c,'cur':num(r.group(1)) if r.group(1) and r.group(1)!='-' else 0,'pri':num(r.group(2)) if r.group(2) else None}
    lines=t.splitlines()
    d['shareholders']=[]
    for ln in lines:
        m2=re.search(r'([A-Z][A-Z .&\'\-]{1,60}?) \((INDIVIDUAL|CORPORATION|TRUST|PARTNERSHIP)\)',ln)
        if m2:
            pct=re.findall(r'(\d{1,3}\.\d{3})',ln)
            d['shareholders'].append({'name':m2.group(1).strip().title(),'type':m2.group(2).title(),'pct_common':float(pct[0]) if pct else None})
    for ln in lines:
        m3=re.search(r'I,\s+950\s+(\S.*?)\s{2,}951\s+(\S.*?)\s{2,}954\s+(\S.*?)\s{2,}',ln)
        if m3:
            d['officer']={'last':m3.group(1).title(),'first':m3.group(2).title(),'position':m3.group(3).title()}; break
    m4=re.search(r'Tax\s+year start.{0,400}?(\d \d \d \d \d \d \d \d)',t,re.S)
    def ln_after(code,maxw=45):
        m6=re.search(r'^\s*'+code+r'\s{2,}(\S.{0,'+str(maxw)+r'}?)(?:\s{3,}|$)',t,re.M)
        return m6.group(1).strip() if m6 else ''
    d['address']={'street':ln_after('011'),'street2':ln_after('012'),'city':ln_after('015',30),
        'prov':(re.search(r'016\s+([A-Z]{2})\b',t) or [None,''])[1],'postal':(re.search(r'018\s+([A-Z]\d[A-Z] ?\d[A-Z]\d)',t) or [None,''])[1]}
    if 'Year Month' in d['address']['street2']: d['address']['street2']=''
    m7=re.search(r'955\s+(\d{4}-\d{2}-\d{2})',t); d['cert_date']=m7.group(1) if m7 else None
    m5=re.search(r'year start\s+((?:\d ){7}\d)\s+year-end\s+((?:\d ){7}\d)',t)
    if m5:
        a=m5.group(1).replace(' ',''); d['year_start']=a[:4]+'-'+a[4:6]+'-'+a[6:]
    m8=re.search(r'Total balance owing \(refund\)\s+([\(\-]?[\d,]+\)?)',t)
    d['balance']=num(m8.group(1)) if m8 else None
    inst=[]; pay_col=None; on=False
    for ln in lines:
        if 'Instalments payable' in ln: pay_col=ln.find('Instalments payable'); on=True; continue
        if on:
            r=re.match(r'^\s*(\d{4}-\d{2}-\d{2})(.*)$',ln)
            if r:
                req=None; pay=None
                for mm in re.finditer(r'[\d,]*\d',r.group(2)):
                    end=ln.find(r.group(2))+mm.end()
                    v=num(mm.group())
                    if pay_col and end>=pay_col: pay=v
                    elif req is None: req=v
                inst.append({'date':r.group(1),'required':req,'payable':pay or 0})
            elif inst and ln.strip()=='' : pass
            elif inst and 'Client:' in ln: on=False
    d['instalments']=inst
    g=lambda pat:(lambda mm: num(mm.group(1)) if mm else 0)(re.search(pat,t))
    d['fed_tax']=g(r'Part I tax payable \(line 700\)[ .]+([\d,]+)')
    d['prov_tax']=g(r'territorial tax payable \(line 760\)[ .]+([\d,]+)')
    d['sbd']=g(r'whichever is the least[ .]+[\d,]+ × 19% =\s+430\s+([\d,]+)')
    d['has_s3_dividends']=bool(re.search(r'T2 SCH 3 E\b',t))  # Schedule 3 page footer; a footnote naming Schedule 3 does not count
    return d
def checks(d):
    b=d['s100']; i=d['s125']; out=[]
    g=lambda s,c,k='cur': (s.get(c) or {}).get(k) or 0
    out.append(('Assets = Liabilities + Equity', g(b,'2599'), g(b,'3499')+g(b,'3620')))
    out.append(('Total L&E (3640) = Assets', g(b,'3640'), g(b,'2599')))
    out.append(('Net income S125 9999 = S100 3680', g(i,'9999'), g(b,'3680')))
    out.append(('RE end = start + NI - dividends (3700)', g(b,'3849'), g(b,'3660')+g(b,'3680')-abs(g(b,'3700'))+g(b,'3720')))
    return [(n,a,c,'OK' if a==c else 'FAIL') for n,a,c in out]
if __name__=='__main__':
    d=parse(sys.argv[1]); print(json.dumps(d,indent=1))
    for c in checks(d): print(c)
