#!/usr/bin/env python3
"""Concept T2 -> compiled FS package.
Usage: python run_package.py T2.pdf --out DIR [--hst 5488.28] [--report-date 2026-09-30]
       [--sh-terms "text"] [--related 2860="ABC Inc."] [--lawyer intake.json]
Stops with STOP: if any tie-out fails. Never guesses a figure."""
import argparse,json,os,subprocess,sys
sys.path.insert(0,os.path.dirname(__file__))
from build_model import build
ap=argparse.ArgumentParser(); ap.add_argument('pdf'); ap.add_argument('--out',required=True)
ap.add_argument('--hst',type=float,default=0); ap.add_argument('--report-date'); ap.add_argument('--sh-terms')
ap.add_argument('--related',action='append',default=[]); ap.add_argument('--lawyer'); ap.add_argument('--email',help='email intake JSON')
a=ap.parse_args(); os.makedirs(a.out,exist_ok=True)
rel=dict(x.split('=',1) for x in a.related)
m=build(a.pdf,int(round(a.hst)),a.report_date,a.sh_terms,rel)
tag='FYE %s %s'%(m['asat'][6:], m['name'])
ye=[k for k in [m['asat']]][0]
import datetime as dt
yeiso=dt.datetime.strptime(m['asat'][6:],'%B %d, %Y').strftime('%Y-%m-%d')
base=os.path.join(a.out,'FYE %s %s'%(yeiso,m['name'].rstrip('.')))
mj=os.path.join(a.out,'model.json'); json.dump(m,open(mj,'w'),indent=1)
here=os.path.dirname(os.path.abspath(__file__))
subprocess.run(['node',os.path.join(here,'render_fs.js'),mj,base+' FS - DRAFT.docx'],check=True)
files=[base+' FS - DRAFT.docx']
subprocess.run(['node',os.path.join(here,'render_mal.js'),mj,base+' MAL - DRAFT.docx'],check=True); files.append(base+' MAL - DRAFT.docx')
if a.lawyer:
    m['lawyer']=json.load(open(a.lawyer)); json.dump(m,open(mj,'w'),indent=1)
    subprocess.run(['node',os.path.join(here,'render_lawyer.js'),mj,base+' Minute Book Letter - DRAFT.docx'],check=True); files.append(base+' Minute Book Letter - DRAFT.docx')
print('FILES:'); [print(' ',f) for f in files]
print('TIE-OUTS:'); [print('  %-40s %10s %10s %s'%c) for c in m['checks']]
print('REVIEW ITEMS:')
print('  Report date: %s (source: %s)'%(m['report_date'],m['report_date_src']))
if m['notes']['shareholder'] and not a.sh_terms: print('  Shareholder note uses standard terms (non-interest bearing, unsecured, no set repayment). Confirm.')
if m['notes']['has_tax'] and not a.hst: print('  Taxes payable not split. Ask whether HST is included.')
for x in m['missing']: print('  MISSING:',x)
if m['has_s3_dividends'] and not a.lawyer: print('  T2 shows Schedule 3 dividends. Ask whether a lawyer keeps the minute book.')

import datetime as _dt
today=_dt.date.today().isoformat()
due=[x for x in (m.get('instalments') or []) if x['payable']>0 and x['date']>=today]
print('EMAIL FACTS:')
b=m.get('balance')
print('  Balance: %s'%('owing $%s'%format(b,',') if b and b>2 else ('refund $%s'%format(-b,',') if b and b<-2 else 'nil')))
if due:
    print('  Next instalment: %s  $%s'%(due[0]['date'],format(due[0]['payable'],',')))
    print('  Later instalments: '+', '.join('%s $%s'%(x['date'],format(x['payable'],',')) for x in due[1:]))
    if b and b>2: print('  Pay by %s: $%s (balance owing + next instalment)'%(due[0]['date'],format(b+due[0]['payable'],',')))
else: print('  Instalments: none payable from today')
print('  BN for payment: '+m['bn15'])

ej=json.load(open(a.email)) if a.email else {}
ej['minute_letter']=bool(a.lawyer); ej.setdefault('fs',True)
ejp=os.path.join(a.out,'email_intake.json'); json.dump(ej,open(ejp,'w'))
subprocess.run([sys.executable,os.path.join(here,'render_email.py'),mj,ejp,base+' Client Email - DRAFT'],check=True)
print('EMAIL FILES:',base+' Client Email - DRAFT.txt / .html')
