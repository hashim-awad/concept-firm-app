#!/usr/bin/env python3
"""Standard client email after T2 filing. Fixed firm wording, conditional blocks.
Input: model.json (from build_model) + email intake JSON. Output: .txt and .html."""
import json,sys,datetime as dt,html,calendar
m=json.load(open(sys.argv[1])); E=json.load(open(sys.argv[2])) if len(sys.argv)>2 and sys.argv[2]!='-' else {}
out=sys.argv[3]
today=dt.date.fromisoformat(E.get('today') or dt.date.today().isoformat())
def D(s): return dt.date.fromisoformat(s)
def fd(d): return d.strftime('%B ')+str(d.day)+d.strftime(', %Y')
def money(v):
    v=round(v,2); return '${:,.2f}'.format(v) if v!=int(v) else '${:,}'.format(int(v))
def add_months(d,n):
    y=d.year+(d.month-1+n)//12; mo=(d.month-1+n)%12+1; return dt.date(y,mo,min(d.day,calendar.monthrange(y,mo)[1]) if d.day<28 else calendar.monthrange(y,mo)[1])
ye=D(m['year_end']); yr=str(ye.year)
first=(m.get('officer') or {}).get('first','')
bn=m['bn15'].replace(' RC 0001',''); rc=bn+' RC 0001'
REVIEW=[]
S=[]  # sections: (title, [lines], kind) kind 'bul' or 'para'
pay_any=False
# ---- A corporate tax
bal=m.get('balance') or 0
ccpc_sbd=(m.get('sbd') or 0)>0
bal_due=add_months(ye,3 if ccpc_sbd else 2); REVIEW.append('Balance-due date %s assumes %s months (%s). Confirm line 896.'%(fd(bal_due),3 if ccpc_sbd else 2,'SBD claimed' if ccpc_sbd else 'no SBD'))
file_due=add_months(ye,6)
filed=D(E['filed_date']) if E.get('filed_date') else (D(m['cert_date']) if m.get('cert_date') else today)
late=filed>file_due
pen=E.get('noa_penalty') or 0; intr=E.get('noa_interest') or 0; noa=E.get('noa_issued',False)
A=[]
if bal>2:
    was='was' if bal_due<today else 'is'
    A.append('The T2 return shows a balance owing of %s. It %s due to the CRA by %s.'%(money(bal),was,fd(bal_due)))
    if late: A.append('The return itself was due %s and was filed late.'%fd(file_due)+(' The CRA\'s Notice of Assessment adds %s for late filing and %s interest to date.'%(money(pen),money(intr)) if noa and pen else (' The CRA\'s Notice of Assessment adds %s interest to date.'%money(intr) if noa and intr else ' The CRA will charge a late-filing penalty and interest on its Notice of Assessment.')))
    elif noa and intr: A.append('The CRA\'s Notice of Assessment adds %s interest to date.'%money(intr))
    tot=bal+(pen if noa else 0)+(intr if noa else 0)
    if bal_due<today: A.append('Please pay %s now. Interest grows every day until it is paid. Pay to business number %s.'%(money(tot),rc))
    else: A.append('Please pay %s by %s. The CRA charges interest on any amount not paid by the due date. Pay to business number %s.'%(money(tot),fd(bal_due),rc))
    if not noa: A.append('The amount may change slightly once the CRA sends its Notice of Assessment. Please forward it to us when it arrives.')
    pay_any=True
elif bal<-2:
    A.append('The T2 return shows a refund of %s. The CRA will send it after it processes the return. No action is needed.'%money(-bal))
    if not noa: A.append('Please forward the Notice of Assessment to us when it arrives.')
else:
    A.append('The T2 return shows no balance owing and no refund. No action is needed.')
    if not noa: A.append('Please forward the Notice of Assessment to us when it arrives.')
S.append(('%s corporate tax'%yr,A,'bul'))
# ---- B GST/HST
H=E.get('hst')
if H:
    rt=bn+' '+H.get('rt','RT 0001'); B=[]
    hb=H.get('balance',0); hdue=D(H['due']) if H.get('due') else None
    if hb>0:
        B.append('The GST/HST return shows a balance owing of %s.'%money(hb)+(' It %s due to the CRA by %s.'%('was' if hdue<today else 'is',fd(hdue)) if hdue else ''))
        B.append('Please pay %s %s. Pay to business number %s. This is a different account from A, so make it a separate payment.'%(money(hb),'now' if (hdue and hdue<today) else ('by '+fd(hdue) if hdue else 'as soon as possible'),rt))
        if hdue and hdue<today: B.append('The CRA may add a late penalty and interest to this amount too.')
        pay_any=True
    elif hb<0: B.append('The GST/HST return shows a refund of %s. The CRA will send it after it processes the return. No action is needed.'%money(-hb))
    else: B.append('The GST/HST return shows no balance owing and no refund. No action is needed.')
    S.append(('%s GST/HST'%yr,B,'bul'))
# ---- C instalments
inst=[x for x in (m.get('instalments') or []) if x['payable']>0 and D(x['date'])>=today]
if inst:
    nxt=add_months(ye,12)
    req=[x for x in m['instalments'] if (x['required'] or 0)>0]
    regular=max(set(x['payable'] for x in inst),key=[x['payable'] for x in inst].count)
    gaps=[(D(b['date'])-D(a['date'])).days for a,b in zip(inst,inst[1:])]
    quarterly=bool(gaps) and min(gaps)>60
    per='every three months' if quarterly else 'each month'; unit='quarter' if quarterly else 'month'
    C=['The CRA wants the corporation to pay its tax a little %s, not all at once after the year ends. These payments are called instalments.'%per]
    months=round(m['days']/30.44)
    fed=m.get('fed_tax') or 0; prov=m.get('prov_tax') or 0
    ann=lambda v: v*365/m['days']
    if m['days']<358 and (ann(fed)>3000 or ann(prov)>3000):
        C.append('Last year, the corporation was open for only %d months. Stretched to a full year, its tax comes to more than $3,000. When that happens, the CRA asks for these payments the next year.'%months)
    elif fed>3000 or prov>3000:
        C.append('Last year, the corporation\'s tax was more than $3,000. When that happens, the CRA asks for these payments the next year.')
    else:
        C.append('The corporation\'s tax for this year is expected to be more than $3,000. When that happens, the CRA asks for these payments during the year.')
        REVIEW.append('Instalments are based on a current-year estimate, not last year. Check the wording in section C.')
    C.append('These payments are not extra tax. They count toward the corporation\'s tax for the year ending %s. If you skip them, the CRA charges interest.'%fd(nxt))
    f=inst[0]
    if f['payable']>regular and req:
        missed=[x for x in req if D(x['date'])<=D(f['date'])]
        n=len(missed)
        C.append('The payments are %s a %s starting in %s. %s have passed, so the first payment catches up %d %ss: %d x %s = %s. The CRA may still charge a small amount of interest on those late %ss.'%(
            money(regular),unit,D(req[0]['date']).strftime('%B'),'%s to %s'%(D(req[0]['date']).strftime('%B'),D(f['date']).strftime('%B')),n,unit,n,money(regular),money(f['payable']),unit))
        if n*regular!=f['payable']: REVIEW.append('Catch-up math check: %d x %s != %s. Fix section C.'%(n,money(regular),money(f['payable'])))
    S.append(('Tax instalments for the year ending %s'%fd(nxt),C,'para'))
    S.append(('Instalment due dates',['%s: %s'%(fd(D(x['date'])),money(x['payable'])) for x in inst]+['Pay instalments to the same RC 0001 account and choose "instalment" as the payment type.'],'dates'))
    pay_any=True
if pay_any: S.append(('How to pay',['Pay through your online banking or through CRA My Payment on the CRA website. Each amount above is its own payment.'],'para'))
docs=['compiled financial statements'] if E.get('fs',True) else []
docs+=['full T2 return','signed T183CORP','CRA e-file confirmation']
if H: docs.append('GST/HST return')
if E.get('minute_letter'): docs.append('minute book letter (please forward it to your lawyer)')
dl=', '.join(docs[:-1])+' and '+docs[-1]
S.append(('Your documents',['Your %s are in your TaxDome portal. The CRA requires you to keep them for 6 years.'%dl],'para'))
subject='%s: FYE %s tax return results'%(m['name'],fd(ye))
opening='We filed the corporation\'s T2 return%s with the CRA.'%(' and its GST/HST return' if H else '')
sig=['Warm regards,','','Hashim Awad, CPA (ON), CPA (US), MFin']
L='ABCDEFGH'
# text
T=['Subject: '+subject,'','Dear %s,'%first,'',opening,'']
for i,(ti,ls,k) in enumerate([s for s in S if s[2]!='dates']):
    pass
i=0; out_sections=[]
for ti,ls,k in S:
    if k=='dates': out_sections.append((None,ti,ls,k)); continue
    out_sections.append((L[i],ti,ls,k)); i+=1
for let,ti,ls,k in out_sections:
    T.append((let+'. ' if let else '')+ti+(':' if not let else ''))
    for j,l in enumerate(ls):
        if k=='para' and j>0: T.append('')
        T.append(('- '+l) if k in('bul','dates') and not l.startswith('Pay instalments') else l)
    T.append('')
T+=sig; open(out+'.txt','w').write('\n'.join(T))
# html (paste into Outlook)
e=html.escape; Hh=['<div style="font-family:Aptos,Calibri,Arial,sans-serif;font-size:11pt">','<p>Dear %s,</p>'%e(first),'<p>%s</p>'%e(opening)]
for let,ti,ls,k in out_sections:
    Hh.append('<p style="margin-bottom:4px"><b style="color:#1A5CA8">%s%s</b></p>'%((let+'. ' if let else ''),e(ti)))
    if k in('bul','dates'):
        items=[l for l in ls if not l.startswith('Pay instalments')]; tail=[l for l in ls if l.startswith('Pay instalments')]
        Hh.append('<ul style="margin-top:0">'+''.join('<li>%s</li>'%e(l) for l in items)+'</ul>')
        for l in tail: Hh.append('<p><b>%s</b></p>'%e(l))
    else: Hh+=['<p>%s</p>'%e(l) for l in ls]
Hh.append('<p>Warm regards,</p><p><b>Hashim Awad</b>, CPA (ON), CPA (US), MFin</p></div>')
open(out+'.html','w').write('\n'.join(Hh))
json.dump({'subject':subject,'review':REVIEW},open(out+'.meta.json','w'),indent=1)
print('\n'.join(T)); print('\nEMAIL REVIEW ITEMS:'); [print('  '+r) for r in REVIEW]
