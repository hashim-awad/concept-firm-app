// Minute book letter to client (to forward to lawyer). Input: model.json + intake dividends.
const fs=require('fs'),path=require('path');
const {Document,Packer,Paragraph,TextRun,Table,TableRow,TableCell,WidthType,AlignmentType,BorderStyle,Header,ImageRun}=require('docx');
const m=JSON.parse(fs.readFileSync(process.argv[2]));const out=process.argv[3];
const F='Arial',SZ=20;const t=(s,o={})=>new TextRun({text:s,font:F,size:o.size||SZ,bold:o.bold,italics:o.it,color:o.color});
const p=(runs,o={})=>new Paragraph({spacing:{after:o.after??160},alignment:o.align,children:Array.isArray(runs)?runs:[t(runs,o)]});
const A=m.addr,tc=s=>s.toLowerCase().replace(/\b\w/g,c=>c.toUpperCase()).replace(/\b(Sw|Se|Nw|Ne)\b/g,x=>x.toUpperCase());
const bd={style:BorderStyle.SINGLE,size:4,color:'999999'},B={top:bd,bottom:bd,left:bd,right:bd};
const cell=(s,w,o={})=>new TableCell({width:{size:w,type:WidthType.DXA},borders:B,shading:o.head?{fill:'E8EDF5',type:'clear',color:'auto'}:undefined,margins:{top:60,bottom:60,left:100,right:100},children:[new Paragraph({alignment:o.right?AlignmentType.RIGHT:AlignmentType.LEFT,children:[t(s,{bold:o.head})]})]});
const tbl=(W,rows,rc=-1)=>new Table({width:{size:W.reduce((a,b)=>a+b),type:WidthType.DXA},columnWidths:W,rows:rows.map((r,i)=>new TableRow({children:r.map((c,j)=>cell(String(c),W[j],{head:i===0,right:i>0&&j===rc}))}))});
const L=m.lawyer; const off=m.officer?(m.officer.first+' '+m.officer.last):'';
const kv=[['Fiscal year end',m.asat.slice(6)],['Financial information dated',m.report_date],['Financial information released',L.released||m.report_date],
 ['Audit waiver',L.audit_waiver||'Yes'],['Our appointment','Accountants (not auditor)'],['Our engagement','Compilation']];
const money=v=>'$'+Number(v).toLocaleString('en-US');
const div=(L.dividends||[]);
const groups=[['Declaration and payment of eligible dividends',div.filter(d=>d.eligible)],['Declaration and payment of dividends other than eligible dividends',div.filter(d=>!d.eligible)]];
let body=[new Paragraph({children:[new ImageRun({type:'png',data:fs.readFileSync(path.join(__dirname,'..','assets','letterhead.png')),transformation:{width:624,height:93}})]}),
 p(' '),p(m.report_date,{after:240}),p(off,{after:0}),p(m.name,{after:0}),p(tc(A.street),{after:0}),p(tc(A.city)+' '+A.prov+'  '+A.postal,{after:240}),
 p('Dear '+off+',',{after:240}),p([t('Re: '+m.name+' minute book',{bold:true})]),
 p('This letter lists the information needed to update the corporation\'s minute book for the year. Please forward a copy to your lawyer.'),
 p([t('Summary of key information',{bold:true})]),tbl([4200,5160],[['Item','Detail'],...kv]),p(' ')];
for(const [h,ds] of groups){ if(!ds.length) continue;
 body.push(p([t(h,{bold:true})]),tbl([2600,2000,2380,2380],[['Share class','Total dividend','Date declared','Date paid'],...ds.map(d=>[d.cls,money(d.amount),d.declared,d.paid])],1),p(' '));}
body.push(p([t('Request for minutes',{bold:true})]),p('Please ask your lawyer to send us a copy of any signed resolutions prepared from this letter.'),
 p('If you have questions, email contact@conceptaccounting.ca or call 226-789-9591.',{after:360}),p('Yours truly,',{after:720}),
 p([t('Hashim Awad, CPA',{bold:true})],{after:0}),p('Concept Accounting & Advisory Professional Corporation'));
const doc=new Document({styles:{default:{document:{run:{font:F,size:SZ}}}},sections:[{properties:{page:{size:{width:12240,height:15840},margin:{top:1080,bottom:1080,left:1440,right:1440}}},
 headers:{default:new Header({children:[new Paragraph({children:[t('DRAFT FOR REVIEW',{bold:true,size:16,color:'C00000'})]})]})},children:body}]});
Packer.toBuffer(doc).then(b=>fs.writeFileSync(out,b));
