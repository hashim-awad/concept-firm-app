---
name: "concept-t2-fs-package"
description: Build Concept Accounting's compiled financial statement package (cover, CSRS 4200 compilation engagement report, balance sheet, statement of earnings and retained earnings, notes), the Management Responsibility Acknowledgement (MAL) and the minute book letter, directly from a filed ProFile T2 PDF. Use whenever a user uploads a ProFile T2 PDF and asks for the FS, compiled financial information, compilation report, year-end package, NTR/compilation package, or minute book / lawyer letter, or says "build the package for this T2". Always use this instead of typing FS by hand.
---

# Concept T2 to Compiled FS Package

Turns a filed ProFile T2 PDF into draft Word files. Figures come only from the T2 (GIFI S100/S125) and the intake answers. Nothing is typed by hand and no figure is ever guessed.

Outputs: FS, MAL (always), minute book letter (with --lawyer), client email. Not in scope: the T2 client cover letter (ProFile prints it, see Notion SOP "ProFile T2 Client Letter: Setup and Printing").

## Workflow (target: files and email ready for review in 10 minutes)

1. **Check the input.** ProFile T2 PDF with a text layer (each page has `Client: NAME  CRA Business # 123456789  Year-end: YYYY-MM-DD`). If not, stop and ask for the ProFile PDF export.

2. **Dry run** to see tie-outs and which questions apply:
   ```bash
   python scripts/run_package.py "<T2.pdf>" --out /home/claude/pkg_out
   ```
   `STOP:` means a tie-out failed. Report it and stop.

3. **Ask every intake question in ONE message** (ask_user_input where it is a choice). Only the ones that apply:
   - Report date (always). If the client has not signed yet, pass a placeholder such as "[Date of signing]". The FS report, MAL and minute book letter share this date, and under CSRS 4200 the report cannot be dated before management signs the MAL.
   - HST included in taxes payable? Amount.
   - Shareholder loan terms (if due to shareholder exists).
   - Related party names (each `MISSING:` line).
   - Has the CRA issued the Notice of Assessment? If yes: late-filing penalty and interest amounts.
   - Was a GST/HST return filed with this package? If yes: balance owing or refund, due date, RT account (default RT 0001).
   - Dividends + lawyer keeps minute book (if Schedule 3 shows dividends): class, amount, eligible, declared date, paid date.

4. **One final run** with everything:
   ```bash
   python scripts/run_package.py "<T2.pdf>" --out /mnt/user-data/outputs \
     --report-date 2026-09-30 --hst 5488.28 [--sh-terms "..."] [--related 2860="ABC Inc."] \
     [--lawyer /home/claude/lawyer.json] --email /home/claude/email.json
   ```
   email.json:
   ```json
   {"noa_issued":true,"noa_penalty":259.07,"noa_interest":136.01,
    "hst":{"balance":5488.28,"due":"2026-03-31","rt":"RT 0001"}}
   ```
   Optional: `"filed_date":"2026-09-24"` (default: T2 line 955 date), `"fs":false` if no FS package.
   lawyer.json: `{"audit_waiver":"Yes","dividends":[{"cls":"Class A common","amount":10000,"eligible":false,"declared":"December 31, 2025","paid":"December 31, 2025"}]}`

5. **Check.** Render each docx to PDF and look at every page. Read the email text once against the T2: amounts, dates, accounts.

6. **Deliver in one message:**
   - Present the files (FS, MAL, minute book letter if any, email .html for pasting into Outlook).
   - Show the email with the message_compose tool (kind email), using the generated .txt exactly. Do not rewrite the standard wording.
   - List tie-outs, script review items, and anything you changed. Mark it DRAFT FOR REVIEW. Nothing goes to the client until Hashim reviews it.

## Client email

`scripts/render_email.py` writes the email from fixed, approved firm wording. Claude does not rewrite it. It picks the blocks that apply:
- **A. Corporate tax:** balance owing (past or future due date, late filing, NOA penalty and interest, total to pay, RC account) or refund or nil. Asks for the NOA when it has not arrived.
- **B. GST/HST** (only if a GST/HST return was filed): owing, refund or nil, RT account, separate payment.
- **C. Instalments** (only if any are payable from today): plain-language explanation, the reason (short prior year stretched to 12 months, or last year's tax over $3,000, or current-year estimate), the catch-up math when the first payment is larger, the due-date list.
- **D. How to pay** (only if money is owed). **E. Documents** in TaxDome (no attachments).

The instalment reason follows the CRA test: federal and provincial tax are tested separately against $3,000, and a short prior year is stretched to 12 months first. Verify the $3,000 threshold on canada.ca before each season. If the CRA changes it, update `render_email.py`.

If Hashim changes the wording, change it in `render_email.py` so every future email uses it. Style rules for any new wording: the hashim-writing-style skill, grade 7 words, amounts before any sentence that refers to them, no em dashes, past due dates written as past.

## What the scripts do

- `parse_t2.py`: reads identity (name, BN, year start/end, head office address, signing officer, certification date), S100 and S125 with current and prior columns, S50 shareholders, and Schedule 3 presence. Runs four tie-outs: assets = liabilities + equity, 3640 = 2599, S125 9999 = S100 3680, RE end = start + NI - dividends + prior period adjustment (3720). Reads current and prior columns of S125 lines 9990 and 9999.
- `build_model.py`: maps GIFI codes to FS captions (`CAP` dictionary), groups current and non-current by GIFI range, merges cash codes 1000 to 1059, splits HST out of 2680, picks "year ended" or "period from X to Y" (under 358 days), drops the prior-year column when empty, and asserts totals again.
- `render_fs.js`: writes the FS docx (cover, compilation report with letterhead, balance sheet, statement of earnings and retained earnings, notes). Notes include only what exists: basis of accounting bullets, GST/HST, due to shareholder.
- `render_email.py`: standard client email (.txt and .html) from the model and email intake.
- `render_mal.js`: Management Responsibility Acknowledgement on plain paper with the corporation's name and address at the top (never firm letterhead, since it is management's letter), addressed to the firm and signed by the T2 signing officer (name, position from T2 line 950-954). Wording follows the firm's MAL: responsibility for the final financial statements and disclosures, and approval of all adjusting entries and reclassifications. Filed as Minute Book slot 05 (SOP 2.06).
- `render_lawyer.js`: minute book letter addressed to the signing officer, to forward to their lawyer. Run it with --lawyer even when there are no dividends (`{"audit_waiver":"Yes","dividends":[]}`); it is Minute Book slot 04.

## Adding a caption

If a GIFI line prints with an awkward label (the fallback is the GIFI label in sentence case), add the code to `CAP` in `scripts/build_model.py`. See `references/gifi_captions.md` for the current list and rules.

## Change log

- 2026-10-05: added MAL (render_mal.js), plain paper, not firm letterhead. Prior period adjustment (3720) in tie-out, RE statement and notes. Prior-year 9990/9999 parsed. Schedule 3 detection uses the schedule footer only. Minute book letter signed Hashim Awad, CPA. Quadrant suffixes (SW, NE) kept in capitals.

## Rules

- Canadian compiled financial information under CSRS 4200. The report wording follows the CSRS 4200 illustrative report. Do not edit it without Hashim.
- Never invent a number, date, name or term. If the T2 or intake does not give it, ask.
- Plain words, no em dashes, in anything added to the documents.
- Client information stays in this client's files only.

## Known limits

- One Schedule 125 only. Multiple S125 / S140 and farming schedules are not handled: stop and tell the user.
- Dividend amounts come from intake, not parsed from Schedule 3.
- Notes cover basis of accounting, GST/HST, source deductions payable, prior period adjustment (3720, generic wording) and due to shareholder. Other notes (amortization at tax rates, income taxes recoverable from a loss carryback, related parties, subsequent events) must be added by hand after generation and flagged in the delivery message.
- If GIFI mapping was corrected in ProFile after printing, reprint the T2 PDF and rerun. Never patch figures by hand.
