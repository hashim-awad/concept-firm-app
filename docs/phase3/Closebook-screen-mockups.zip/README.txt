Closebook screen mockups (approved Nov 11, 2026). Sample figures only.
1 Main.html                My files (work queue)
2 FileDocuments.html       Client file, Documents tab
3 RevenueCheck.html        A document page: revenue check
4 FileTrialBalance.html    Client file, Trial balance tab
5 FileEntries.html         Full file, Entries tab
6 FileStatements.html      Client file, Statements tab
7 SetupGifi.html           Settings, Closebook group, GIFI lines
Markup is a design reference (layout, labels, order). Build with Studio's own components and styles.
