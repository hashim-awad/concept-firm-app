TaxDome transaction questions: benchmark screenshots for round 32.
Client data is blurred. The other figures are Concept's own test company.
Copy the layout and the flow. Never show TaxDome's name or logo.
Where these differ from the round 32 message, the message wins.

01 Staff: "Ask client" on a transaction. Saved questions, a 400-character box, "Add to favorites", Send.
02 Staff: a saved question picked into the box.
03 Staff: the notice after a question is added, and the "Notify client" button.
04 Client: the email as received. One link, "View transaction questions", and the sender's signature.
05 Client: TaxDome's portal login. NOT USED. Closebook uses a 6-digit code sent to the email address instead.
06 Client: one question. Transaction details left, the question middle, answer box with Send and Attach file right.
07 Client: three questions, tabs "Waiting for answer / Answered / All".
08 Staff: an answered question back in the list, with the answer and the attachment count.
09 Staff: hover on the answer shows the whole thread (Q, A, Q, A) and "1 file attached".
